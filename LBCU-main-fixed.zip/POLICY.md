## Defensa Operativa

Este repositorio está protegido bajo principios de trazabilidad científica, reproducibilidad operativa y defensa documental. Cualquier uso indebido será rastreado, documentado y expuesto públicamente como parte del protocolo de integridad TCDS.
